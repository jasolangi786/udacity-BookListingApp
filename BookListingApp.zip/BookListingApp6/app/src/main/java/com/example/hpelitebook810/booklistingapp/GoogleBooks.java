package com.example.hpelitebook810.booklistingapp;

public class GoogleBooks {
    private String book;
    private String coverPhoto;

    public GoogleBooks(String book, String thumbnail) {
        this.book = book;
        this.coverPhoto = thumbnail;
    }

    public String getBook() {
        return book;
    }

    public void setBook(String book) {
        this.book = book;
    }

    public String getCoverPhoto() {
        return coverPhoto;
    }

    public void setCoverPhoto(String coverPhoto) {
        this.coverPhoto = coverPhoto;
    }
}