package com.example.hpelitebook810.booklistingapp;

import android.content.Context;
import android.view.LayoutInflater;

import com.bumptech.glide.Glide;

import android.view.View;

import java.util.List;

import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class GoogleBooksAdapter extends ArrayAdapter<GoogleBooks> {
    private Context context;

    public GoogleBooksAdapter(Context context, int resource, List<GoogleBooks> books) {
        super(context, resource, books);
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater layoutInflater = LayoutInflater.from(getContext());
            view = layoutInflater.inflate(R.layout.google_books_items, null);
        }

        GoogleBooks book = getItem(position);

        if (book != null) {
            ImageView thumbnail = (ImageView) view.findViewById(R.id.google_books_cover_photo);
            TextView title = (TextView) view.findViewById(R.id.google_books_cover);
            title.setText(book.getBook());
            Glide.with(context).load(book.getCoverPhoto()).into(thumbnail);
        }
        return view;
    }
}