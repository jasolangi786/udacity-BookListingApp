package com.example.hpelitebook810.booklistingapp;

import android.app.SearchManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BooksListingActivity extends AppCompatActivity {

    private ListView booksListView;
    private List<GoogleBooks> mBooks;
    private GoogleBooksAdapter mGoogleBooksAdapter;
    private TextView blank_listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.books_listing_activity);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mBooks = new ArrayList<GoogleBooks>();

        booksListView = (ListView) findViewById(R.id.googleBooksListView);
        mGoogleBooksAdapter = new GoogleBooksAdapter(this, R.layout.google_books_items, mBooks);
        booksListView.setAdapter(mGoogleBooksAdapter);
        blank_listView = (TextView) findViewById(R.id.blank_listView);
        booksListView.setEmptyView(blank_listView);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(menu.findItem(R.id.action_search));
        SearchManager searchManager = (SearchManager) getSystemService(SEARCH_SERVICE);
        ConnectivityManager cManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo nInfo = cManager.getActiveNetworkInfo();
        if (nInfo == null) {
            Toast.makeText(this, "There is no Internet connection", Toast.LENGTH_LONG).show();
        }
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }

            @Override
            public boolean onQueryTextSubmit(String query) {
                new fetchNewsTask().execute(query);
                return false;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    private class fetchNewsTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection urlConnection = null;

            try {

                String bookParam = (params[0]);
                URL url = new URL("https://www.googleapis.com/books/v1/volumes?q=" + bookParam + "&maxResults=15");
                Log.d("Requested URL", "https://www.googleapis.com/books/v1/volumes?q=" + bookParam + "&maxResults=15");
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();
                int status = urlConnection.getResponseCode();
                Log.d("HTTPStatus", Integer.toString(status));
                switch (status) {
                    case 200:
                        BufferedReader bufferReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;
                        while ((line = bufferReader.readLine()) != null) {
                            stringBuilder.append(line + "\n");
                        }
                        bufferReader.close();
                        return stringBuilder.toString();
                    default:

                        Log.d("HTTP REQUEST", "BAD RESPONSE");
                }

            } catch (MalformedURLException ex) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
            } finally {
                if (urlConnection != null) {
                    try {
                        urlConnection.disconnect();
                    } catch (Exception ex) {
                        Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            mBooks.clear();
            if (result != null) {
                JsonParser parser = new JsonParser();
                JsonObject element = parser.parse(result).getAsJsonObject();
                JsonElement responseList = element.get("items");
                if (responseList != null) {
                    JsonArray googleBooks = responseList.getAsJsonArray();

                    for (JsonElement book : googleBooks) {
                        JsonObject bookObj = book.getAsJsonObject();
                        JsonElement bookVolumeInfo = bookObj.get("volumeInfo");
                        JsonObject bookVolumeInfoObj = bookVolumeInfo.getAsJsonObject();

                        JsonElement bookTitle = bookVolumeInfoObj.get("title");
                        Type listType = new TypeToken<List<String>>() {
                        }.getType();
                        List<String> authorsList = new Gson().fromJson(bookVolumeInfoObj.get("authors"), listType);
                        String parsedBookTitle = bookTitle.toString().substring(1, bookTitle.toString().length() - 1);
                        String bookDetails;
                        if (authorsList != null && authorsList.size() > 0) {
                            bookDetails = parsedBookTitle + " by " + authorsList.get(0);
                            for (int i = 1; i < authorsList.size(); i++) {
                                bookDetails += ", " + authorsList.get(i);
                            }
                        } else {
                            bookDetails = parsedBookTitle;
                        }
                        JsonElement imageLinks = bookVolumeInfoObj.get("imageLinks");
                        if (imageLinks != null) {
                            JsonObject imageLinksObj = imageLinks.getAsJsonObject();
                            String imageUrl = imageLinksObj.get("smallThumbnail").toString();
                            mBooks.add(new GoogleBooks(bookDetails, imageUrl.substring(1, imageUrl.length() - 1)));
                        } else {
                            mBooks.add(new GoogleBooks(bookDetails, ""));
                        }
                    }
                } else {
                    blank_listView.setText(getString(R.string.no_books_found));
                }
            }
            mGoogleBooksAdapter.notifyDataSetChanged();
        }

    }
}